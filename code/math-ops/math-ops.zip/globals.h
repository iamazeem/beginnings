#ifndef _GLOBALS_
#define _GLOBALS_

// Key Codes
#define EXTENDED    0
#define ENTER       13
#define ESC         27
#define UP          72
#define DOWN        80

enum bool { false = 0, true = 1 };

#endif // _GLOBALS_