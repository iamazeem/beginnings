#include "math_ops.h"

int main()
{
    MathOps::start();
    return 0;
}
